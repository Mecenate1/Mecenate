from lib.megaserver.client import Client
from lib.megaserver.server import Server
__all__ = ['Client', 'Server']
